function mostrarAlerta() {
    alert("Você clicou no botão!");
}

// Exemplo de efeito ao passar o mouse sobre a galeria de imagens
const imagens = document.querySelectorAll('.gallery img');

imagens.forEach(imagem => {
    imagem.addEventListener('mouseover', () => {
        imagem.style.transform = 'scale(1.1)';
        imagem.style.transition = '0.3s';
    });

    imagem.addEventListener('mouseout', () => {
        imagem.style.transform = 'scale(1)';
    });
});
